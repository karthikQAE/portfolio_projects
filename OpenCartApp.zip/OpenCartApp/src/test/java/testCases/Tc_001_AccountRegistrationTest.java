package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import pageObjects.RegistrationPage;
import testBase.BaseClass;

public class Tc_001_AccountRegistrationTest extends BaseClass 
{

	@Test(groups= {"Regression", "Master"})
	void test_Acc_Reg() throws InterruptedException 
	{
		
		logger.info("***  Starting TC_001_AccountRegistrationTest ***");
		
	  try 
	  {
		  
	HomePage hp = new HomePage(driver);
	hp.clickMyAccount();
	logger.info("clicked on MyAccount link ");
	hp.clickRegister();
	logger.info("clicked on Register link ");
	
	RegistrationPage regpage = new RegistrationPage(driver);
	
	logger.info("providing customers data");
	regpage.settFirstName(randomeString().toUpperCase());
	regpage.setLastName(randomeString().toUpperCase());
	regpage.setEmail(randomeString()+"@gmail.com");
	regpage.setPassword(randomepassword());
	//regpage.clk_radiobtn_subcribe();
	//regpage.clk_btn_Agree();
	//Thread.sleep(5000);
	//regpage.clk_btn_continue();
	
	Assert.assertEquals(driver.getCurrentUrl(), "https://demo.opencart.com/index.php?route=account/register&language=en-gb");
	logger.info("Validating done ");
	
	  }
	  
	  catch(Exception e) 
	  {
		  logger.error("fail");
		  Assert.fail();	  
	  }
	  
	  logger.info("***  finished TC_001_AccountRegistrationTest ***");
	  }
		}
