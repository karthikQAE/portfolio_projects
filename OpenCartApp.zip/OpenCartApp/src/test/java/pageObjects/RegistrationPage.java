
package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RegistrationPage extends BasePage {
	
	public RegistrationPage(WebDriver driver){
		
		super(driver);
	}
	
	
	@FindBy(xpath="//input[@id='input-firstname']")
	WebElement txtFirstName;
	
	@FindBy(xpath="//input[@id='input-lastname']")
	WebElement txtLastName;
	
	@FindBy(xpath="//input[@id='input-email']")
	WebElement txtEmail;
	
	@FindBy(xpath="//input[@id='input-password']")
	WebElement txtPassword;
	
	@FindBy(xpath="//input[@id='input-newsletter-yes']")
	WebElement radiobtn_subcribe;
	
	@FindBy(xpath="//input[@name='agree']")
	WebElement btn_Agree;
	
	@FindBy(xpath="//button[normalize-space()='Continue']")
	WebElement btn_continue;
	
	@FindBy(xpath="//h1[normalize-space()='Your Account Has Been Created!']")
	WebElement msg_confirm;
	
	
	public void settFirstName(String fname)
	{
		txtFirstName.sendKeys(fname);
	}
	
	public void setLastName(String lname)
	{
		txtLastName.sendKeys(lname);
	}
	
	public void setEmail(String email)
	{
		txtEmail.sendKeys(email);
	}
	
	public void setPassword(String passWord)
	{
		txtPassword.sendKeys(passWord);
	}
	
	public void clk_radiobtn_subcribe()
	{
		radiobtn_subcribe.click();
	}
	
	public void clk_btn_Agree()
	{
		btn_Agree.click();
	}
	
	public void clk_btn_continue()
	{
		btn_continue.click();
	}
	
	public String msg_confirm()
	{
		try 
		{
		return (msg_confirm.getText());
		}
		
		catch(Exception e)
		{
			return(e.getMessage());
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
